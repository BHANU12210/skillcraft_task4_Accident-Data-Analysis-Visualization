import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

df = pd.read_csv("accidentdata.csv", low_memory=False)


os.makedirs("outputs/plots", exist_ok=True)


df['Start_Time'] = pd.to_datetime(df['Start_Time'], errors='coerce')
df['Hour'] = df['Start_Time'].dt.hour
df['DayOfWeek'] = df['Start_Time'].dt.day_name()


plt.figure(figsize=(8,5))
df['Severity'].value_counts().sort_index().plot(kind='bar', color='skyblue')
plt.title("Accidents by Severity Level")
plt.xlabel("Severity")
plt.ylabel("Count")
plt.tight_layout()
plt.savefig("outputs/plots/accidents_by_severity.png")
plt.close()


plt.figure(figsize=(10,5))
df['Weather_Condition'].value_counts().nlargest(10).plot(kind='bar', color='salmon')
plt.title("Top 10 Weather Conditions in Accidents")
plt.xlabel("Weather Condition")
plt.ylabel("Count")
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig("outputs/plots/accidents_by_weather.png")
plt.close()


plt.figure(figsize=(10,5))
df['Hour'].value_counts().sort_index().plot(kind='bar', color='orange')
plt.title("Accidents by Hour of Day")
plt.xlabel("Hour")
plt.ylabel("Count")
plt.tight_layout()
plt.savefig("outputs/plots/accidents_by_hour.png")
plt.close()


plt.figure(figsize=(10,5))
order = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
df['DayOfWeek'].value_counts().reindex(order).plot(kind='bar', color='green')
plt.title("Accidents by Day of the Week")
plt.xlabel("Day")
plt.ylabel("Count")
plt.tight_layout()
plt.savefig("outputs/plots/accidents_by_day.png")
plt.close()


plt.figure(figsize=(6,5))
df['Sunrise_Sunset'].value_counts().plot(kind='bar', color='purple')
plt.title("Day vs Night Accidents")
plt.xlabel("Time of Day")
plt.ylabel("Count")
plt.tight_layout()
plt.savefig("outputs/plots/accidents_by_sunrise_sunset.png")
plt.close()


plt.figure(figsize=(8,6))
corr = df[['Severity', 'Visibility(mi)', 'Hour']].corr()
sns.heatmap(corr, annot=True, cmap='coolwarm', fmt=".2f")
plt.title("Correlation Heatmap")
plt.tight_layout()
plt.savefig("outputs/plots/correlation_heatmap.png")
plt.close()


